export const API_URL_USER =
  "https://income-expenses-tracker-web-dev.onrender.com/api/v1/users";
export const API_URL_ACC =
  "https://income-expenses-tracker-web-dev.onrender.com/api/v1/users/api/v1/accounts";
export const API_URL_TRANSACTION =
  "https://income-expenses-tracker-web-dev.onrender.com/api/v1/users/api/v1/transactions";

// export const API_URL_USER =
//   "https://radiant-peak-71363.herokuapp.com/api/v1/users";
// export const API_URL_ACC =
//   "https://radiant-peak-71363.herokuapp.com/api/v1/accounts";
// export const API_URL_TRANSACTION =
//   "https://radiant-peak-71363.herokuapp.com/api/v1/transactions";

//https://radiant-peak-71363.herokuapp.com/
